##
## This script is sourced by /data/data/com.oc.ide/files/usr/bin/login before executing shell.
##
